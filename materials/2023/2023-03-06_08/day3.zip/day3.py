import numpy as np
from pytket.circuit import Circuit, OpType, Unitary1qBox
psi=(np.cos(1),np.exp(1*1j)*np.sin(1))
psip=(np.sin(1),-np.exp(1*1j)*np.cos(1))
psi_u = np.asarray([[psi[0], psip[0]],
                 [psi[1], psip[1]]])
conj_psi_u = np.conjugate(psi_u.T)
u1box_psid = Unitary1qBox(conj_psi_u)
shot = 10000
def var(res):
    v=0
    n=0
    for i in res.values():
        v += ((1 - n) - i/shot)**2
        n += 1 
    return v